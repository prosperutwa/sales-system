<?php echo $__env->make('partials.side-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container w-75 my-4" id="container-main">

    <div class="card border-0 shadow-sm rounded">
        <div class="card-header border-top border-primary border-0 bg-white d-flex justify-content-between align-items-center">
            <h6 class="mb-0">Invoice #<?php echo e(str_pad($invoice->auto_id, 4, '0', STR_PAD_LEFT)); ?></h6>
            <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
        </div>

        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-12">
                    <img src="<?php echo e(asset('assets/img/header/header.png')); ?>" width="100%">
                </div>
                <div class="col-md-6">
                    <h5><?php echo e($company->company_name ?? 'Company Name'); ?></h5>
                    <p>
                        <?php echo e($company->company_address ?? ''); ?> <br>
                        Phone: <?php echo e($company->company_phone ?? ''); ?> <br>
                        Email: <?php echo e($company->company_email ?? ''); ?>

                    </p>
                </div>
                <div class="col-md-6 text-end">
                    <h6>Invoice To:</h6>
                    <p>
                        <?php echo e($invoice->customer->full_name ?? '-'); ?> <br>
                        <?php echo e($invoice->customer->company_name ?? ''); ?> <br>
                        Phone: <?php echo e($invoice->customer->phone ?? '-'); ?> <br>
                        Email: <?php echo e($invoice->customer->email ?? '-'); ?>

                    </p>
                    <p><strong>Date:</strong> <?php echo e($invoice->created_at->format('d M Y')); ?></p>
                    <p><strong>Status:</strong> 
                        <?php
                        $statusClass = match($invoice->status) {
                            'unpaid'   => 'badge bg-secondary',
                            'paid'     => 'badge bg-success',
                            'cancelled' => 'badge bg-danger',
                            default    => 'badge bg-light',
                        };
                        ?>
                        <span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($invoice->status)); ?></span>
                    </p>
                </div>
            </div>

            <div class="table-responsive mb-4">
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th>Price (Tsh)</th>
                            <th>Quantity</th>
                            <th>Subtotal (Tsh)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total = 0; ?>
                        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $subtotal = $item->quantity * $item->product->selling_price;
                        $total += $subtotal;
                        ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->product->name ?? '-'); ?></td>
                            <td><?php echo e(number_format($item->product->selling_price, 2)); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e(number_format($subtotal, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="row mb-4">
                <div class="col-md-6"></div>
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <th>Total:</th>
                            <td>Tsh <?php echo e(number_format($total, 2)); ?></td>
                        </tr>
                        <tr>
                            <th>Discount:</th>
                            <td>Tsh <?php echo e(number_format($invoice->discount_amount, 2)); ?></td>
                        </tr>
                        <tr>
                            <th>Amount Due:</th>
                            <td><strong>Tsh <?php echo e(number_format($invoice->total_amount, 2)); ?></strong></td>
                        </tr>
                    </table>
                </div>
            </div>

            <?php if($invoice->status == "paid"): ?>
            <h6>Payments</h6>
            <div class="table-responsive mb-4">
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Method</th>
                            <th>Reference</th>
                            <th>Amount (Tsh)</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                            <td><?php echo e($payment->reference_no ?? '-'); ?></td>
                            <td><?php echo e(number_format($payment->amount_paid, 2)); ?></td>
                            <td><?php echo e($payment->created_at->format('d M Y H:i')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No payments yet</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <center>
                <div class="qr-code">
                    <?php echo $qrCode; ?>

                </div>
            </center>


            <div class="text-end">
                <a href="<?php echo e(route('invoices.print', $invoice->auto_id)); ?>" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</a>
                <a href="<?php echo e(route('invoices.download', $invoice->auto_id)); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-download"></i> Download</a>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sales-system/resources/views/templates/admin/view-invoice.blade.php ENDPATH**/ ?>