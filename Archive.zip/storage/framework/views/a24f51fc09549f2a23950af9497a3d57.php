<?php $__env->startSection('content'); ?>

<style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 13px;
        background: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    .invoice-container {
        width: 850px;
        margin: 30px auto;
        background: #ffffff;
        padding: 20px;
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }

    .header-image img {
        width: 100%;
        margin-bottom: 15px;
    }

    .invoice-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .company-info h4 {
        margin: 0 0 5px 0;
        font-size: 16px;
    }

    .company-info p,
    .customer-info p {
        margin: 2px 0;
        line-height: 1.4;
    }

    .customer-info {
        text-align: right;
    }

    .invoice-meta {
        margin: 15px 0;
    }

    .invoice-title {
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .status {
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 12px;
        display: inline-block;
        color: #fff;
    }

    .status.paid { background: #28a745; }
    .status.unpaid { background: #6c757d; }
    .status.cancelled { background: #dc3545; }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table th,
    table td {
        border: 1px solid #ddd;
        padding: 8px;
    }

    table th {
        background: #f2f2f2;
        text-align: left;
    }

    .text-right {
        text-align: right;
    }

    .totals-table {
        width: 300px;
        margin-left: auto;
    }

    .totals-table td {
        border: none;
        padding: 5px 0;
    }

    .totals-table tr:last-child td {
        font-weight: bold;
        border-top: 1px solid #ddd;
        padding-top: 8px;
    }

    .qr-section {
        text-align: center;
        margin-top: 25px;
    }

    .qr-section p {
        margin-top: 8px;
        font-size: 12px;
        color: #555;
    }

    @media print {
        body {
            background: #ffffff;
        }

        .invoice-container {
            width: 100%;
            margin: 0;
            box-shadow: none;
            border-radius: 0;
        }
    }
</style>

<div class="invoice-container">

    <div class="header-image">
        <img src="<?php echo e(asset('assets/img/header/header.png')); ?>">
    </div>

    <div class="invoice-header">
        <div class="company-info">
            <h4><?php echo e($company->company_name ?? 'Company Name'); ?></h4>
            <p><?php echo e($company->company_address ?? ''); ?></p>
            <p>Phone: <?php echo e($company->company_phone ?? ''); ?></p>
            <p>Email: <?php echo e($company->company_email ?? ''); ?></p>
        </div>

        <div class="customer-info">
            <p><strong>Invoice To</strong></p>
            <p><?php echo e($invoice->customer->full_name ?? '-'); ?></p>
            <p><?php echo e($invoice->customer->company_name ?? ''); ?></p>
            <p>Phone: <?php echo e($invoice->customer->phone ?? '-'); ?></p>
            <p>Email: <?php echo e($invoice->customer->email ?? '-'); ?></p>
            <p><strong>Date:</strong> <?php echo e($invoice->created_at->format('d M Y')); ?></p>

            <span class="status <?php echo e($invoice->status); ?>">
                <?php echo e(ucfirst($invoice->status)); ?>

            </span>
        </div>
    </div>

    <div class="invoice-meta">
        <div class="invoice-title">
            Invoice #<?php echo e(str_pad($invoice->auto_id, 4, '0', STR_PAD_LEFT)); ?>

        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Product</th>
                <th>Price (Tsh)</th>
                <th>Qty</th>
                <th>Subtotal (Tsh)</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subtotal = $item->quantity * $item->product->selling_price;
                    $total += $subtotal;
                ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($item->product->name ?? '-'); ?></td>
                    <td class="text-right"><?php echo e(number_format($item->product->selling_price, 2)); ?></td>
                    <td class="text-right"><?php echo e($item->quantity); ?></td>
                    <td class="text-right"><?php echo e(number_format($subtotal, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table class="totals-table">
        <tr>
            <td>Total</td>
            <td class="text-right">Tsh <?php echo e(number_format($total, 2)); ?></td>
        </tr>
        <tr>
            <td>Discount</td>
            <td class="text-right">Tsh <?php echo e(number_format($invoice->discount_amount, 2)); ?></td>
        </tr>
        <tr>
            <td>Amount Due</td>
            <td class="text-right">Tsh <?php echo e(number_format($invoice->total_amount, 2)); ?></td>
        </tr>
    </table>

    <?php if($invoice->status === 'paid'): ?>
        <h4>Payments</h4>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Amount (Tsh)</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                        <td><?php echo e($payment->reference_no ?? '-'); ?></td>
                        <td class="text-right"><?php echo e(number_format($payment->amount_paid, 2)); ?></td>
                        <td><?php echo e($payment->created_at->format('d M Y H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">No payments found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div class="qr-section">
        <?php echo $qrCode; ?>

    </div>

</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

<script>
async function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'mm', 'a4');
    
    const element = document.querySelector('.invoice-container');
    
    const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
    });
    
    const imgData = canvas.toDataURL('image/jpeg', 1.0);
    
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    
    const imgWidth = pageWidth - 20; 
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    doc.addImage(imgData, 'JPEG', 10, 10, imgWidth, imgHeight);
    
    doc.save(`invoice_<?php echo e(str_pad($invoice->auto_id, 4, '0', STR_PAD_LEFT)); ?>.pdf`);

    setTimeout(()=>{
        window.history.back();
    }, 100);
}
</script>


<?php if($action == "print"): ?>
<script>
    window.print();
</script>
<?php else: ?>
<script>
    generatePDF()
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sales-system/resources/views/templates/admin/invoices/print.blade.php ENDPATH**/ ?>