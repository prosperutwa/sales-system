<?php echo $__env->make('partials.side-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4">

    <h4 class="mb-4">Dashboard</h4>

    <div class="row">

      <a href="#" class="col-xl-4 col-md-6 mb-4"  style="text-decoration: none;">
        <div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                            Users
                        </div>

                        <div class="h6 mb-1 font-weight-bold text-gray-800">
                            <?php echo e($totalUsers); ?>

                        </div>
                    </div>
                    <div class="col-auto text-danger icon-dashboard">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </a>

    <a href="#" class="col-xl-4 col-md-6 mb-4"
    style="text-decoration: none;">
    <div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                        Products
                    </div>
                    <div class="h6 mb-1 font-weight-bold text-gray-800">
                        <?php echo e($totalProducts); ?>

                    </div>
                </div>
                <div class="col-auto text-info icon-dashboard">
                    <i class="fas fa-envelope fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</a>

<a href="#" target="_blank" class="col-xl-4 col-md-6 mb-4"
style="text-decoration: none;">
<div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
    <div class="card-body">
        <div class="row no-gutters align-items-center">
            <div class="col mr-2">
                <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                    Customers
                </div>
                <div class="h6 mb-1 font-weight-bold text-gray-800">
                    <?php echo e($totalCustomers); ?>

                </div>
            </div>
            <div class="col-auto text-success icon-dashboard">
                <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
        </div>
    </div>
</div>
</a>

<a href="#" target="_blank" class="col-xl-4 col-md-6 mb-4"
style="text-decoration: none;">
<div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
    <div class="card-body">
        <div class="row no-gutters align-items-center">
            <div class="col mr-2">
                <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                    Invoices
                </div>
                <div class="h6 mb-1 font-weight-bold text-gray-800">
                    <?php echo e($totalInvoices); ?>

                </div>
            </div>
            <div class="col-auto text-warning icon-dashboard">
                <i class="fas fa-file-invoice fa-2x text-gray-300"></i>
            </div>
        </div>
    </div>
</div>
</a>

<a href="#" target="_blank" class="col-xl-4 col-md-6 mb-4"
style="text-decoration: none;">
<div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
    <div class="card-body">
        <div class="row no-gutters align-items-center">
            <div class="col mr-2">
                <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                    Total Payments
                </div>
                <div class="h6 mb-1 font-weight-bold text-gray-800">
                    <?php echo e(number_format($totalPayments,2)); ?> Tsh
                </div>
            </div>
            <div class="col-auto text-primary icon-dashboard">
                <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
            </div>
        </div>
    </div>
</div>
</a>

<a href="#" target="_blank" class="col-xl-4 col-md-6 mb-4"
style="text-decoration: none;">
<div class="card h-100 py-2 border-0 shadow-sm" style="background-color: white; position: static;">
    <div class="card-body">
        <div class="row no-gutters align-items-center">
            <div class="col mr-2">
                <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                    Total Profit
                </div>
                <div class="h6 mb-1 font-weight-bold text-gray-800">
                    <?php echo e(number_format($totalProfit,2)); ?> Tsh
                </div>
            </div>
            <div class="col-auto text-secondary icon-dashboard">
                <i class="fas fa-money-check-alt fa-2x text-gray-300"></i>
            </div>
        </div>
    </div>
</div>
</a>
</div>


<div class="row mb-4">
    <div class="col-md-6">
        <div class="card p-3 border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6>Monthly Sales</h6>
            </div>
            <div class="card-body">
                <canvas id="monthlySalesChart" height="200"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card p-3 border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6>Top 5 Sold Products</h6>
            </div>
            <div class="card-body">
                <canvas id="topProductsChart" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="card p-3 border-0 shadow-sm">
    <div class="card-header bg-white">
        <h6>Top Selling Products</h6>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Quantity Sold</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($prod->name); ?></td>
                    <td><?php echo e($prod->total_sold); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const monthlyLabels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const monthlyData = [
        <?php for($i=1; $i<=12; $i++): ?>
        <?php echo e($monthlySales[$i] ?? 0); ?>,
        <?php endfor; ?>
    ];

    new Chart(document.getElementById('monthlySalesChart'), {
        type: 'bar',
        data: {
            labels: monthlyLabels,
            datasets: [{
                label: 'Monthly Sales (Tsh)',
                data: monthlyData,
                backgroundColor: '#0d6efd'
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } }
        }
    });

    const topProductsLabels = [
        <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($prod->name); ?>',
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    const topProductsData = [
        <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($prod->total_sold); ?>,
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];

    new Chart(document.getElementById('topProductsChart'), {
        type: 'doughnut',
        data: {
            labels: topProductsLabels,
            datasets: [{
                data: topProductsData,
                backgroundColor: ['#0d6efd','#198754','#ffc107','#dc3545','#6c757d']
            }]
        },
        options: { responsive: true }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sales-system/resources/views/templates/admin/dashboard.blade.php ENDPATH**/ ?>